﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace dgubbaFinalProject.Models.Database
{
    public class Claims
    {
        public const string IsTeacher = "IsTeacher";
        public const string IsStudent = "IsStudent";
    }
}
