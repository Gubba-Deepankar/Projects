﻿delete from Assessments;
delete from StudentAssignmentTable;